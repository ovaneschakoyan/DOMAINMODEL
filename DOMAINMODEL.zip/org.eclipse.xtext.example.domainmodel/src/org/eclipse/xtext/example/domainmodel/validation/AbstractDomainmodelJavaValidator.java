package org.eclipse.xtext.example.domainmodel.validation;

public class AbstractDomainmodelJavaValidator {

}
