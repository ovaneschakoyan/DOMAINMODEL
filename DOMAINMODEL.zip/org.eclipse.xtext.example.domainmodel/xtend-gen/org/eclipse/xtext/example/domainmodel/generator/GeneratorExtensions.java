package org.eclipse.xtext.example.domainmodel.generator;

import org.eclipse.xtext.example.domainmodel.DomainmodelExtensions;
import org.eclipse.xtext.example.domainmodel.domainmodel.Entity;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class GeneratorExtensions extends DomainmodelExtensions {
  public String qualifiedName(final Entity t) {
    String _xifexpression = null;
    boolean _isNullOrEmpty = StringExtensions.isNullOrEmpty(this.packageName(t));
    if (_isNullOrEmpty) {
      _xifexpression = t.getName();
    } else {
      String _packageName = this.packageName(t);
      String _plus = (_packageName + ".");
      String _name = t.getName();
      _xifexpression = (_plus + _name);
    }
    return _xifexpression;
  }
  
  public String fileName(final Entity e) {
    String _folderName = this.folderName(this.packageName(e));
    String _plus = (_folderName + "/");
    String _name = e.getName();
    String _plus_1 = (_plus + _name);
    return (_plus_1 + ".java");
  }
  
  public String folderName(final String javaPackageName) {
    String _xifexpression = null;
    if ((javaPackageName != null)) {
      _xifexpression = javaPackageName.replace(".", "/");
    } else {
      _xifexpression = "";
    }
    return _xifexpression;
  }
}
