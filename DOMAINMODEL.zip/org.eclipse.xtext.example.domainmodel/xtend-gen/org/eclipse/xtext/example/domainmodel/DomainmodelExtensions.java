package org.eclipse.xtext.example.domainmodel;

import org.eclipse.xtext.example.domainmodel.domainmodel.Entity;

@SuppressWarnings("all")
public class DomainmodelExtensions {
  public String packageName(final Entity o) {
    return "entity";
  }
}
