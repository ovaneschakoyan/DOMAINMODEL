package org.eclipse.xtext.example.domainmodel;

public class DomainmodelValidator {

}
